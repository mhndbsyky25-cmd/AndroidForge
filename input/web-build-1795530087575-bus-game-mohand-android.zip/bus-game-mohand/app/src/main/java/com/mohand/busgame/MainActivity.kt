package com.mohand.busgame

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(GameView(this))
    }
}

class GameView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val random = Random(System.nanoTime())

    private var viewW = 0f
    private var viewH = 0f
    private var centerX = 0f
    private var horizonY = 0f
    private var halfBottom = 0f

    private var busLane = 1f
    private var targetLane = 1
    private var speed = 0.32f
    private var meters = 0f
    private var coins = 0
    private var best = 0
    private var started = false
    private var gameOver = false

    private var spawnTimer = 0.6f
    private var lastTime = 0L

    private val items = ArrayList<Item>()

    private class Item(val lane: Int, var t: Float, val coin: Boolean)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        viewW = w.toFloat()
        viewH = h.toFloat()
        centerX = w / 2f
        horizonY = h * 0.34f
        halfBottom = w * 0.66f
        lastTime = 0L
    }

    private fun yAt(t: Float): Float {
        val e = t.coerceIn(0f, 1.15f)
        return horizonY + (viewH - horizonY) * (e * e)
    }

    private fun halfWAt(t: Float): Float {
        val e = t.coerceIn(0f, 1.15f)
        return halfBottom * (0.05f + 0.95f * (e * e))
    }

    private fun laneX(lane: Float, t: Float): Float =
        centerX + (lane - 1f) * 0.60f * halfWAt(t)

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastTime == 0L) 0f else ((now - lastTime) / 1_000_000_000f).coerceAtMost(0.05f)
        lastTime = now

        if (started && !gameOver) update(dt)

        drawScene(canvas)
        drawHud(canvas)

        if (!started) {
            drawPanel(
                canvas,
                "اضغط للبدء",
                "حرّك الباص يمين ويسار\nاجمع النقود وتجنب السيارات"
            )
        } else if (gameOver) {
            drawPanel(
                canvas,
                "انتهت اللعبة",
                "المسافة: " + meters.toInt() + " م\n" +
                    "النقود: " + coins + "\n" +
                    "أفضل نتيجة: " + best + "\n" +
                    "اضغط للعب من جديد"
            )
        }

        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        speed = (0.32f + meters / 1200f).coerceAtMost(1.5f)
        meters += speed * dt * 40f
        busLane += (targetLane.toFloat() - busLane) * min(1f, dt * 9f)

        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawn()
            spawnTimer = (0.55f + random.nextFloat() * 0.55f) / (speed * 1.6f)
        }

        val it = items.iterator()
        while (it.hasNext()) {
            val o = it.next()
            o.t += speed * dt
            val sameLane = abs(o.lane - busLane) < 0.45f
            if (o.coin) {
                if (o.t in 0.78f..0.97f && sameLane) {
                    coins++
                    it.remove()
                    continue
                }
            } else {
                if (o.t in 0.78f..0.97f && sameLane) {
                    endGame()
                    return
                }
            }
            if (o.t > 1.2f) it.remove()
        }
    }

    private fun spawn() {
        val lane = random.nextInt(3)
        val coin = random.nextFloat() < 0.45f
        items.add(Item(lane, 0f, coin))
    }

    private fun endGame() {
        gameOver = true
        val score = meters.toInt()
        if (score > best) best = score
    }

    private fun reset() {
        items.clear()
        meters = 0f
        coins = 0
        speed = 0.32f
        busLane = 1f
        targetLane = 1
        spawnTimer = 0.6f
        lastTime = 0L
    }

    private fun drawScene(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            0f, 0f, 0f, horizonY,
            Color.parseColor("#8FD6FF"),
            Color.parseColor("#E8F6FF"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, viewW, horizonY, paint)
        paint.shader = null

        paint.color = Color.parseColor("#3E7D3A")
        canvas.drawRect(0f, horizonY, viewW, viewH, paint)

        path.reset()
        path.moveTo(centerX - halfWAt(0f), yAt(0f))
        path.lineTo(centerX + halfWAt(0f), yAt(0f))
        path.lineTo(centerX + halfBottom, viewH)
        path.lineTo(centerX - halfBottom, viewH)
        path.close()
        paint.color = Color.parseColor("#3A3F47")
        canvas.drawPath(path, paint)

        paint.color = Color.parseColor("#F2F2F2")
        var t = 0.10f
        while (t < 1.02f) {
            val t2 = min(t + 0.04f, 1.12f)
            for (d in floatArrayOf(0.5f, 1.5f)) {
                val xa = centerX + (d - 1f) * 0.60f * halfWAt(t)
                val xb = centerX + (d - 1f) * 0.60f * halfWAt(t2)
                val w1 = 0.012f * halfWAt(t) + 1.5f
                val w2 = 0.012f * halfWAt(t2) + 1.5f
                path.reset()
                path.moveTo(xa - w1, yAt(t))
                path.lineTo(xa + w1, yAt(t))
                path.lineTo(xb + w2, yAt(t2))
                path.lineTo(xb - w2, yAt(t2))
                path.close()
                canvas.drawPath(path, paint)
            }
            t += 0.10f
        }

        val sorted = items.sortedBy { it.t }
        for (o in sorted) {
            if (o.t < 0f || o.t > 1.1f) continue
            val x = laneX(o.lane.toFloat(), o.t)
            val y = yAt(o.t)
            if (o.coin) drawCoin(canvas, x, y, o.t) else drawCar(canvas, x, y, o.t)
        }

        drawBus(canvas)
    }

    private fun drawCoin(canvas: Canvas, x: Float, y: Float, t: Float) {
        val r = 0.055f * halfWAt(t) + 4f
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#F7C948")
        canvas.drawCircle(x, y - r, r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.20f
        paint.color = Color.parseColor("#B98A00")
        canvas.drawCircle(x, y - r, r * 0.68f, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawCar(canvas: Canvas, x: Float, y: Float, t: Float) {
        val w = 0.23f * halfWAt(t) + 8f
        val h = w * 1.25f
        val left = x - w / 2f
        val top = y - h

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#33000000")
        rect.set(left, top + h * 0.92f, left + w, top + h * 1.06f)
        canvas.drawOval(rect, paint)

        rect.set(left, top, left + w, y)
        paint.color = Color.parseColor("#D64545")
        canvas.drawRoundRect(rect, w * 0.18f, w * 0.18f, paint)

        rect.set(left + w * 0.15f, top + h * 0.12f, left + w * 0.85f, top + h * 0.52f)
        paint.color = Color.parseColor("#20303F")
        canvas.drawRoundRect(rect, w * 0.08f, w * 0.08f, paint)

        paint.color = Color.parseColor("#1B1B1B")
        rect.set(left + w * 0.02f, y - h * 0.22f, left + w * 0.22f, y + h * 0.02f)
        canvas.drawRect(rect, paint)
        rect.set(left + w * 0.78f, y - h * 0.22f, left + w * 0.98f, y + h * 0.02f)
        canvas.drawRect(rect, paint)
    }

    private fun drawBus(canvas: Canvas) {
        val t = 0.90f
        val cx = laneX(busLane, t)
        val w = viewW * 0.24f
        val h = w * 1.35f
        val bottom = viewH * 0.985f
        val top = bottom - h
        val left = cx - w / 2f

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#33000000")
        rect.set(left - w * 0.06f, bottom - h * 0.06f, left + w * 1.06f, bottom + h * 0.04f)
        canvas.drawOval(rect, paint)

        rect.set(left, top, left + w, bottom)
        paint.color = Color.parseColor("#FFB300")
        canvas.drawRoundRect(rect, w * 0.10f, w * 0.10f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w * 0.025f
        paint.color = Color.parseColor("#8A5A00")
        canvas.drawRoundRect(rect, w * 0.10f, w * 0.10f, paint)
        paint.style = Paint.Style.FILL

        rect.set(left + w * 0.10f, top + h * 0.10f, left + w * 0.90f, top + h * 0.45f)
        paint.color = Color.parseColor("#2B3E50")
        canvas.drawRoundRect(rect, w * 0.06f, w * 0.06f, paint)

        rect.set(left + w * 0.05f, top + h * 0.52f, left + w * 0.95f, top + h * 0.60f)
        paint.color = Color.parseColor("#2E7D32")
        canvas.drawRect(rect, paint)

        paint.color = Color.parseColor("#D32F2F")
        canvas.drawCircle(left + w * 0.18f, top + h * 0.72f, w * 0.055f, paint)
        canvas.drawCircle(left + w * 0.82f, top + h * 0.72f, w * 0.055f, paint)

        paint.color = Color.parseColor("#1B1B1B")
        rect.set(left + w * 0.02f, bottom - h * 0.16f, left + w * 0.20f, bottom)
        canvas.drawRoundRect(rect, w * 0.03f, w * 0.03f, paint)
        rect.set(left + w * 0.80f, bottom - h * 0.16f, left + w * 0.98f, bottom)
        canvas.drawRoundRect(rect, w * 0.03f, w * 0.03f, paint)
    }

    private fun drawHud(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textSize = viewH * 0.026f
        paint.setShadowLayer(viewH * 0.004f, 0f, viewH * 0.003f, Color.BLACK)

        paint.textAlign = Paint.Align.LEFT
        canvas.drawText(meters.toInt().toString() + " م", viewW * 0.05f, viewH * 0.075f, paint)

        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("النقود: " + coins, viewW * 0.95f, viewH * 0.075f, paint)

        paint.clearShadowLayer()
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawPanel(canvas: Canvas, title: String, body: String) {
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#CC000000")
        canvas.drawRect(0f, 0f, viewW, viewH, paint)

        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = viewH * 0.052f
        canvas.drawText(title, centerX, viewH * 0.45f, paint)

        paint.textSize = viewH * 0.028f
        var y = viewH * 0.53f
        for (line in body.split("\n")) {
            canvas.drawText(line, centerX, y, paint)
            y += viewH * 0.042f
        }
        paint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!started || gameOver) {
                    reset()
                    started = true
                    gameOver = false
                    return true
                }
                setLaneFromTouch(event.x)
            }
            MotionEvent.ACTION_MOVE -> {
                if (started && !gameOver) setLaneFromTouch(event.x)
            }
        }
        return true
    }

    private fun setLaneFromTouch(x: Float) {
        val half = 0.60f * halfWAt(0.9f)
        val lane = (x - centerX) / half + 1f
        targetLane = lane.roundToInt().coerceIn(0, 2)
    }
}
