package com.mohand.chatai;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.FirebaseException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public final class MainActivity extends Activity {
    private FirebaseAuth auth;
    private String verificationId;
    private LinearLayout root, login;
    private TextView status;
    private EditText phone, code;
    private CheckBox smsConsent;
    private WebView web;
    private final Executor ui = command -> runOnUiThread(command);
    private WebViewAssetLoader assets;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        assets = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        setContentView(root);
        String project=getString(R.string.firebase_project_id), appId=getString(R.string.firebase_android_app_id), apiKey=getString(R.string.firebase_api_key);
        if (project.startsWith("YOUR_") || appId.startsWith("YOUR_") || apiKey.startsWith("YOUR_")) {
            showLogin("إعداد Firebase مطلوب قبل تشغيل تسجيل الدخول، راجع التعليمات داخل ملف المشروع"); return;
        }
        try {
            FirebaseOptions options=new FirebaseOptions.Builder().setProjectId(project).setApplicationId(appId).setApiKey(apiKey).build();
            if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this,options);
            auth=FirebaseAuth.getInstance(); auth.setLanguageCode("ar");
            if (auth.getCurrentUser()!=null) showChat(); else showLogin("سجّل دخولك للمتابعة");
        } catch (Exception e) { showLogin("تعذر إعداد Firebase، راجع القيم وإعدادات المشروع"); }
    }
    private Button button(String text) { Button b=new Button(this); b.setText(text); b.setAllCaps(false); return b; }
    private void destroyWeb(){ if(web!=null){ ((ViewGroup)web.getParent()).removeView(web); web.destroy(); web=null; } }
    private void showLogin(String info){
        destroyWeb(); root.removeAllViews();
        login=new LinearLayout(this); login.setOrientation(LinearLayout.VERTICAL); login.setPadding(32,32,32,32); login.setGravity(Gravity.CENTER_HORIZONTAL); root.addView(login);
        TextView title=new TextView(this); title.setText("chat mohand"); title.setTextSize(24); login.addView(title);
        status=new TextView(this); status.setText(info); login.addView(status);
        Button google=button("متابعة باستخدام Google"); login.addView(google); google.setOnClickListener(v->googleSignIn());
        phone=new EditText(this); phone.setSingleLine(true); phone.setInputType(InputType.TYPE_CLASS_PHONE); phone.setHint("رقم الهاتف الدولي، مثال +963..."); login.addView(phone);
        smsConsent=new CheckBox(this); smsConsent.setText("أوافق على استخدام رقمي للتحقق، وقد تطبّق رسوم رسائل SMS"); login.addView(smsConsent);
        Button send=button("إرسال رمز التحقق"); login.addView(send); send.setOnClickListener(v->sendPhoneCode());
        code=new EditText(this); code.setSingleLine(true); code.setInputType(InputType.TYPE_CLASS_NUMBER); code.setHint("رمز التحقق"); login.addView(code);
        Button confirm=button("تأكيد الرمز"); login.addView(confirm); confirm.setOnClickListener(v->confirmCode());
    }
    private void googleSignIn(){
        if(auth==null){status.setText("يلزم إعداد Firebase أولاً");return;}
        String client=getString(R.string.google_web_client_id);
        if(client.startsWith("YOUR_")){status.setText("أضف معرّف Google Web Client في إعدادات المشروع");return;}
        try {
            GetGoogleIdOption option=new GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(client).build();
            GetCredentialRequest request=new GetCredentialRequest.Builder().addCredentialOption(option).build();
            CredentialManager.create(this).getCredentialAsync(this,request,null,ui,new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse response){
                    try {
                        Credential c=response.getCredential();
                        if (!(c instanceof CustomCredential) || !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {status.setText("تعذر قراءة بيانات Google");return;}
                        String token=GoogleIdTokenCredential.createFrom(c.getData()).getIdToken();
                        auth.signInWithCredential(GoogleAuthProvider.getCredential(token,null)).addOnCompleteListener(MainActivity.this, task->{if(task.isSuccessful())showChat();else status.setText("تعذر تسجيل Google، راجع Firebase و SHA-1");});
                    }catch(Exception e){status.setText("تعذر إكمال تسجيل Google");}
                }
                @Override public void onError(GetCredentialException e){status.setText("تعذر تسجيل Google أو تم إلغاؤه");}
            });
        }catch(Exception e){status.setText("تعذر فتح تسجيل Google على هذا الجهاز");}
    }
    private void sendPhoneCode(){
        if(auth==null){status.setText("يلزم إعداد Firebase أولاً");return;}
        if(!smsConsent.isChecked()){status.setText("الموافقة على استخدام الرقم مطلوبة");return;}
        String n=phone.getText().toString().replaceAll("[\\s()\\-]","");
        if(!n.matches("\\+[1-9][0-9]{7,14}")){status.setText("اكتب الرقم بصيغة دولية");return;}
        PhoneAuthProvider.OnVerificationStateChangedCallbacks callbacks=new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
            @Override public void onVerificationCompleted(PhoneAuthCredential credential){finishPhone(credential);}
            @Override public void onVerificationFailed(FirebaseException e){status.setText("تعذر التحقق بالرقم، راجع الإعدادات والبلد والإنترنت");}
            @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token){verificationId=id; status.setText("إذا وصلتك الرسالة أدخل الرمز");}
        };
        try {PhoneAuthOptions options=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(n).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(callbacks).build();PhoneAuthProvider.verifyPhoneNumber(options);status.setText("جاري طلب رمز التحقق");}
        catch(Exception e){status.setText("تعذر إرسال رمز التحقق");}
    }
    private void confirmCode(){String c=code.getText().toString().trim(); if(verificationId==null||!c.matches("[0-9]{6}")){status.setText("اطلب الرمز وأدخله من 6 أرقام");return;}finishPhone(PhoneAuthProvider.getCredential(verificationId,c));}
    private void finishPhone(PhoneAuthCredential credential){auth.signInWithCredential(credential).addOnCompleteListener(this,task->{if(task.isSuccessful()){verificationId=null;showChat();}else status.setText("الرمز غير صحيح أو انتهى، أو تعذر تسجيل الدخول");});}
    private void configureWeb(WebView w){WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setSupportMultipleWindows(true);s.setJavaScriptCanOpenWindowsAutomatically(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(w,true);}
    private void external(Uri u){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}}
    private void showChat(){
        root.removeAllViews(); LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
        TextView title=new TextView(this);title.setText("chat mohand");title.setTextSize(16);bar.addView(title);
        Button out=button("خروج");bar.addView(out);root.addView(bar);out.setOnClickListener(v->{auth.signOut();showLogin("تم تسجيل الخروج من حساب التطبيق");});
        web=new WebView(this);configureWeb(web);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){return assets.shouldInterceptRequest(request.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){Uri u=request.getUrl();if("https".equals(u.getScheme()) && "appassets.androidplatform.net".equals(u.getHost()))return false;external(u);return true;}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onCreateWindow(WebView parent,boolean dialog,boolean gesture,Message result){
                WebView popup=new WebView(MainActivity.this);configureWeb(popup);
                Dialog d=new Dialog(MainActivity.this);d.setContentView(popup);d.setOnDismissListener(x->popup.destroy());
                popup.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){Uri u=req.getUrl();if("https".equals(u.getScheme()))return false;external(u);return true;}});
                popup.setWebChromeClient(new WebChromeClient(){@Override public void onCloseWindow(WebView w){d.dismiss();}});
                WebView.WebViewTransport transport=(WebView.WebViewTransport)result.obj;transport.setWebView(popup);result.sendToTarget();d.show();return true;
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){destroyWeb();super.onDestroy();}
}
