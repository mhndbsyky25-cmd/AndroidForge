MOHAND Telegram Android safe modification patch

This ZIP is an overlay patch, not the complete Telegram source tree and not an APK. It contains modified app-name resources, launcher icon resources, purple accent constants, and the built-in Dark Blue theme palette adjusted toward the dark-purple colors. Extract it into the matching Telegram source repository root and allow the files to overwrite. Choose the app's Dark Blue night theme to see the dark palette.

Applied: the app label is mohand in existing AppName and AppNameBeta translations; launcher images use the included custom icon. Day-theme accent is #893BCC; the existing dark theme retains dark surfaces and uses purple accents. The supplied screenshot did not expose a full app theme, so the colors are an approximation, not a pixel match.

Not applied: the 10-account cap and a universal 10-digit phone rule. Source currently stores 4 Java account entries, allows 3 accounts without Premium and 5 with Premium, while native code allocates 5. Raising this to 10 would bypass the current paid account tier and needs cross-language changes; this patch does not crack Premium or alter the cap. Phone entry remains country-specific and Telegram's servers may reject a number even if it has 10 digits.

To get a complete build tree, clone the official source with submodules: git clone --recursive --shallow-submodules https://github.com/DrKLO/Telegram.git Telegram. A GitHub source ZIP omits initialized submodules. The source README lists Android Studio 2025.1.4, Android SDK 36 and NDK 27.2.12479018; you also need your own API credentials, Firebase configuration, and signing setup. No APK build or device test was run.

The original repository uses GPL-2.0. Follow its license and Telegram's developer guidance, keep the app clearly unofficial, use your own API ID from https://my.telegram.org/apps, and publish your source changes if you distribute a derived build.

Sources: https://github.com/DrKLO/Telegram and its README. Patch files are based on the master snapshot retrieved 2026-11-24.
