#!/usr/bin/env python3
"""Small static web server for chat mohand. AI requests go from the browser to Puter.js."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
STATIC_ASSETS = {
    '/icon-192.png': ('icon-192.png', 'image/png'),
    '/icon-512.png': ('icon-512.png', 'image/png'),
    '/manifest.webmanifest': ('manifest.webmanifest', 'application/manifest+json; charset=utf-8'),
    '/firebase-config.js': ('firebase-config.js', 'application/javascript; charset=utf-8'),
}


class Handler(BaseHTTPRequestHandler):
    def send_data(self, status, data, content_type='text/plain; charset=utf-8'):
        body = data if isinstance(data, bytes) else data.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/':
            filename, content_type = 'index.html', 'text/html; charset=utf-8'
        else:
            asset = STATIC_ASSETS.get(self.path)
            if asset is None:
                self.send_data(404, 'Not found')
                return
            filename, content_type = asset
        try:
            self.send_data(200, (ROOT / filename).read_bytes(), content_type)
        except OSError:
            self.send_data(404, 'Asset missing')

    def do_POST(self):
        self.send_data(405, 'Method not allowed')

    def log_message(self, fmt, *args):
        super().log_message(fmt, *args)


if __name__ == '__main__':
    print('افتح على نفس الجهاز: http://127.0.0.1:5000')
    print('إيقاف السيرفر: Ctrl+C')
    ThreadingHTTPServer(('127.0.0.1', 5000), Handler).serve_forever()
