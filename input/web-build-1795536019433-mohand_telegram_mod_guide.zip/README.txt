mohand | دليل تخصيص Telegram Android

محتويات الحزمة: تعليمات تعديل الاسم، أيقونة تجريبية 512×512، وخطوات البناء مع مصادرها. هذه ليست نسخة APK ولا patch كامل، ولم يتم بناء التطبيق أو اختباره على جهاز.

المستودع المقصود: https://github.com/DrKLO/Telegram

النتيجة التقنية:
- الاسم mohand قابل للتغيير في موارد التطبيق. التغييرات الدقيقة موجودة في PATCH-INSTRUCTIONS.txt.
- الأيقونة المرفقة فكرة أصلية بألوان وردي/بنفسجي/أزرق مستوحاة من الجزء الظاهر في لقطة الشاشة؛ بقية الواجهة مطموسة، لذلك لا أقدر أقول إنها تطابق شاشة كاملة.
- UserConfig.java يعلن MAX_ACCOUNT_DEFAULT_COUNT = 3 وMAX_ACCOUNT_COUNT = 4، بينما getMaxAccountCount يرجع 5 إذا فيه حساب Premium و3 بدونه. Defines.h يعلن MAX_ACCOUNT_COUNT = 5، وConnectionsManager.cpp يوجّه الخانات 0 إلى 4. القيم بين Java وnative غير متطابقة؛ ما في تعديل بسيط أقدر أؤكد منه دعم 10 حسابات. وما أساعد بتجاوز حد Premium المدفوع. الوصول لعشرة يتطلب إعادة تصميم وتدقيق كل أنظمة الحسابات ثم اختبارًا فعليًا.
- تسجيل الدخول يقسم الرقم إلى مفتاح دولة ورقم محلي ويرسله إلى Telegram؛ PhoneFormat يتحقق وفق البلد. لذلك ما في طول موحد 10 أرقام لكل البلدان، والرقم ذو 10 خانات لا يصبح مقبولًا إذا لم يكن صحيحًا لخطة ترقيم البلد أو لم تقبله خوادم Telegram.

خطوات التعديل والبناء:
1. على كمبيوتر، ثبّت Android Studio 2025.1.4 وAndroid SDK 36 وAndroid NDK 27.2.12479018. محاولة AndroidForge السابقة لم تنجح، فلا تعتمد عليه لهذا البناء.
2. نزّل المشروع مع الوحدات الفرعية:
   git clone --recursive --shallow-submodules https://github.com/DrKLO/Telegram.git Telegram
3. افتح مجلد Telegram نفسه في Android Studio، وليس عبر Import.
4. خذ api_id وapi_hash من https://my.telegram.org/apps، ثم عيّن القيم المطلوبة في TMessagesProj/src/main/java/org/telegram/messenger/BuildVars.java. لا تشارك المفاتيح أو ملف keystore.
5. لبناء release اتبع README الرسمي لإعداد Firebase وgoogle-services.json وrelease.keystore. لا ترفع الأسرار إلى مستودع عام.
6. من جذر المشروع شغّل الأمر المذكور في Dockerfile للمشروع:
   ./gradlew :TMessagesProj_App:assembleAfatRelease
7. ملف app.apk متوقع ضمن TMessagesProj_App/build/outputs/apk/afat/release/ بعد نجاح Gradle؛ لم أنفذ بناءً للتحقق من الناتج.

ملاحظات:
- Android Studio يحتاج كمبيوتر. يمكن تشغيل البناء عبر GitHub Actions بعد إعداد workflow مناسب، لكن لم أتحقق من وجود workflow جاهز لهذا الغرض في المستودع.
- لا تغيّر applicationId عشوائيًا؛ إعداد Firebase وخدمات Android تعتمد عليه.
- المستودع مرخّص GPL-2.0 ويطلب نشر مصدر التعديلات عند توزيع تطبيق مشتق. تعليمات Telegram تطلب api_id خاصًا، وعدم استخدام اسم Telegram أو شعاره لتطبيق غير رسمي.
- Telegram تقول إن حسابات مستخدمي عملاء غير رسميين تخضع للمراقبة لتجنّب إساءة الاستخدام؛ خرق شروطها قد يسبب الحظر.

مصادر:
https://github.com/DrKLO/Telegram
https://github.com/DrKLO/Telegram/blob/master/README.md
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/java/org/telegram/messenger/UserConfig.java
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/jni/tgnet/Defines.h
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/jni/tgnet/ConnectionsManager.cpp
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/java/org/telegram/ui/LoginActivity.java
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/java/org/telegram/PhoneFormat/PhoneFormat.java
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/java/org/telegram/ui/ActionBar/ThemeColors.java
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/config/release/AndroidManifest.xml
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
https://core.telegram.org/api/obtaining_api_id
https://developer.android.com/studio/write/create-app-icons
